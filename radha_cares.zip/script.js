// JavaScript functionality
document.addEventListener("DOMContentLoaded", () => {
    console.log("Radha Cares website loaded successfully!");
});
